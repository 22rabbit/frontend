export {default as Framework} from "./Framework"
export{default as Maingraph} from "./Maingraph"
export{default as Detail} from "./Detail"